


// localStorage.setItem("cssQuestions", JSON.stringify(cssQuestions));


// console.log(JSON.parse(localStorage.getItem("cssQuestions")));



const cssQuestions = [
  {
    id: 1,
    question: "Which CSS property is used to change the text color?",
    options: [
      "A) color",
      "B) text-color",
      "C) font-color",
      "D) background-color"
    ],
    answer: "A) color"
  },
  {
    id: 2,
    question: "How do you apply a style to an element with the class name 'example'?",
    options: [
      "A) #example",
      "B) .example",
      "C) *example",
      "D) example"
    ],
    answer: "B) .example"
  },
  {
    id: 3,
    question: "Which property is used to set the space between elements?",
    options: [
      "A) padding",
      "B) margin",
      "C) border-spacing",
      "D) spacing"
    ],
    answer: "B) margin"
  },
  {
    id: 4,
    question: "How do you center text in CSS?",
    options: [
      "A) text-align: center;",
      "B) align-text: center;",
      "C) center-text: yes;",
      "D) text-center: true;"
    ],
    answer: "A) text-align: center;"
  },
  {
    id: 5,
    question: "Which CSS property controls the size of the font?",
    options: [
      "A) font-size",
      "B) text-size",
      "C) font-style",
      "D) text-style"
    ],
    answer: "A) font-size"
  },
  {
    id: 6,
    question: "How can you add a border to an element in CSS?",
    options: [
      "A) border: 1px solid black;",
      "B) border-color: black;",
      "C) border-width: 1px;",
      "D) border-style: solid;"
    ],
    answer: "A) border: 1px solid black;"
  },
  {
    id: 7,
    question: "Which property is used to set the background color of an element?",
    options: [
      "A) background-color",
      "B) bg-color",
      "C) color-background",
      "D) background"
    ],
    answer: "A) background-color"
  },
  {
    id: 8,
    question: "How do you create a CSS class?",
    options: [
      "A) .classname { ... }",
      "B) #classname { ... }",
      "C) *classname { ... }",
      "D) classname { ... }"
    ],
    answer: "A) .classname { ... }"
  },
  {
    id: 9,
    question: "Which property is used to control the spacing between lines of text?",
    options: [
      "A) line-height",
      "B) text-spacing",
      "C) letter-spacing",
      "D) font-spacing"
    ],
    answer: "A) line-height"
  },
  {
    id: 10,
    question: "How do you specify a font in CSS?",
    options: [
      "A) font-family: Arial;",
      "B) font-type: Arial;",
      "C) text-font: Arial;",
      "D) font: Arial;"
    ],
    answer: "A) font-family: Arial;"
  },
  {
    id: 11,
    question: "Which property is used to make text bold in CSS?",
    options: [
      "A) font-weight",
      "B) font-style",
      "C) text-weight",
      "D) font-bold"
    ],
    answer: "A) font-weight"
  },
  {
    id: 12,
    question: "What does the 'padding' property do in CSS?",
    options: [
      "A) Adds space inside an element",
      "B) Adds space outside an element",
      "C) Adds a border around an element",
      "D) Changes the element's color"
    ],
    answer: "A) Adds space inside an element"
  },
  {
    id: 13,
    question: "Which property is used to set the width of an element in CSS?",
    options: [
      "A) width",
      "B) element-width",
      "C) size",
      "D) margin-width"
    ],
    answer: "A) width"
  },
  {
    id: 14,
    question: "How do you hide an element in CSS?",
    options: [
      "A) display: none;",
      "B) visibility: hidden;",
      "C) hide: true;",
      "D) opacity: 0;"
    ],
    answer: "A) display: none;"
  },
  {
    id: 15,
    question: "Which CSS property is used to align text to the right?",
    options: [
      "A) text-align: right;",
      "B) text-align: left;",
      "C) align-text: right;",
      "D) text-position: right;"
    ],
    answer: "A) text-align: right;"
  },
  {
    id: 16,
    question: "How do you set the height of an element in CSS?",
    options: [
      "A) height: 100px;",
      "B) size: 100px;",
      "C) element-height: 100px;",
      "D) height-size: 100px;"
    ],
    answer: "A) height: 100px;"
  },
  {
    id: 17,
    question: "Which property is used to set the border style of an element?",
    options: [
      "A) border-style",
      "B) border-type",
      "C) border-width",
      "D) border-color"
    ],
    answer: "A) border-style"
  },
  {
    id: 18,
    question: "What does the 'overflow' property do in CSS?",
    options: [
      "A) Controls content that overflows an element's box",
      "B) Sets the border of an element",
      "C) Changes the font size",
      "D) Aligns text"
    ],
    answer: "A) Controls content that overflows an element's box"
  },
  {
    id: 19,
    question: "How can you apply a style to an element with an ID of 'header'?",
    options: [
      "A) #header { ... }",
      "B) .header { ... }",
      "C) *header { ... }",
      "D) header { ... }"
    ],
    answer: "A) #header { ... }"
  },
  {
    id: 20,
    question: "Which CSS property is used to set the transparency level of an element?",
    options: [
      "A) opacity",
      "B) transparency",
      "C) alpha",
      "D) visibility"
    ],
    answer: "A) opacity"
  }
];




var num = 0;

let continueEle = document.getElementById("continue");




function createEle(){
let javascriptQuestionDivEle = document.getElementById("css-question-div");

  
while (javascriptQuestionDivEle.firstChild) {
javascriptQuestionDivEle.removeChild(javascriptQuestionDivEle.firstChild);}


let obj = cssQuestions[num]

// question
let QuestionEle = document.createElement("h1");
QuestionEle.classList.add("head");
QuestionEle.textContent=obj.id+" "+ obj.question;
javascriptQuestionDivEle.appendChild(QuestionEle)

// option

for (let option of obj.options){

let optionsEle = document.createElement("li");
optionsEle.classList.add("btn");
optionsEle.textContent=option;
javascriptQuestionDivEle.appendChild(optionsEle)
}

//answer
let answerButtonEle =  document.createElement("h2");
answerButtonEle.textContent ="Answer "+ obj.answer[0];
answerButtonEle.classList.add("answer-button");
javascriptQuestionDivEle.appendChild(answerButtonEle);


}

createEle();




// Intervels
let spanEle = document.getElementById("span");
let counter = 60;

let uniqueId = setInterval(function() {
  counter -= 1;
  spanEle.textContent=counter
  if (counter === 0){
  clearInterval(uniqueId);
  window.location.replace(`../Loss/YouLossPage.html`);
}
}, 1000);


continueEle.onclick = function(){

  if(num<19){
  counter = 60;
  num+=1;
  createEle();
  }
  else{
     window.location.replace(`../Win/WinPage.html`);
  }

}




















