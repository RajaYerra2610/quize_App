

// localStorage.setItem("javascriptQuestions", JSON.stringify(javascriptQuestions));

const javascriptQuestions = [
  {
    id: 1,
    question: "Which company developed JavaScript?",
    options: [
      "A) Netscape",
      "B) Microsoft",
      "C) Sun Microsystems",
      "D) Oracle"
    ],
    answer: "A) Netscape"
  },
  {
    id: 2,
    question: "Which symbol is used for comments in JavaScript?",
    options: [
      "A) <!-- -->",
      "B) //",
      "C) /* */",
      "D) ##"
    ],
    answer: "B) //"
  },
  {
    id: 3,
    question: "Which method is used to select an element by its ID in JavaScript?",
    options: [
      "A) getElementById()",
      "B) querySelector()",
      "C) getElementsByClassName()",
      "D) getElementByTag()"
    ],
    answer: "A) getElementById()"
  },
  {
    id: 4,
    question: "Which keyword is used to declare a constant in JavaScript?",
    options: [
      "A) var",
      "B) let",
      "C) const",
      "D) constant"
    ],
    answer: "C) const"
  },
  {
    id: 5,
    question: "How do you write 'Hello World' in an alert box?",
    options: [
      "A) alertBox('Hello World');",
      "B) msg('Hello World');",
      "C) msgBox('Hello World');",
      "D) alert('Hello World');"
    ],
    answer: "D) alert('Hello World');"
  },
  {
    id: 6,
    question: "How do you create a function in JavaScript?",
    options: [
      "A) function = myFunction()",
      "B) function myFunction()",
      "C) myFunction = function()",
      "D) Both B and C"
    ],
    answer: "D) Both B and C"
  },
  {
    id: 7,
    question: "Which of the following is a JavaScript data type?",
    options: [
      "A) String",
      "B) Number",
      "C) Boolean",
      "D) All of the above"
    ],
    answer: "D) All of the above"
  },
  {
    id: 8,
    question: "What will the following code output? console.log(typeof null);",
    options: [
      "A) null",
      "B) object",
      "C) undefined",
      "D) number"
    ],
    answer: "B) object"
  },
  {
    id: 9,
    question: "How do you add an element to the end of an array in JavaScript?",
    options: [
      "A) push()",
      "B) pop()",
      "C) unshift()",
      "D) shift()"
    ],
    answer: "A) push()"
  },
  {
    id: 10,
    question: "Which of the following is used to convert a string to an integer in JavaScript?",
    options: [
      "A) parseInt()",
      "B) parseFloat()",
      "C) Number()",
      "D) toFixed()"
    ],
    answer: "A) parseInt()"
  },
  {
    id: 11,
    question: "How can you add a comment in JavaScript?",
    options: [
      "A) // This is a comment",
      "B) <!-- This is a comment -->",
      "C) /* This is a comment */",
      "D) Both A and C"
    ],
    answer: "D) Both A and C"
  },
  {
    id: 12,
    question: "Which operator is used to assign a value to a variable?",
    options: [
      "A) *",
      "B) -",
      "C) =",
      "D) +"
    ],
    answer: "C) ="
  },
  {
    id: 13,
    question: "Which method can be used to find the length of a string?",
    options: [
      "A) length()",
      "B) size()",
      "C) len()",
      "D) .length"
    ],
    answer: "D) .length"
  },
  {
    id: 14,
    question: "Which of the following is NOT a reserved word in JavaScript?",
    options: [
      "A) interface",
      "B) throws",
      "C) program",
      "D) short"
    ],
    answer: "C) program"
  },
  {
    id: 15,
    question: "How can you convert a JSON string to a JavaScript object?",
    options: [
      "A) JSON.stringify()",
      "B) JSON.parse()",
      "C) JSON.objectify()",
      "D) parse.JSON()"
    ],
    answer: "B) JSON.parse()"
  },
  {
    id: 16,
    question: "Which method can be used to add an event listener in JavaScript?",
    options: [
      "A) onEvent()",
      "B) addEvent()",
      "C) addEventListener()",
      "D) listenTo()"
    ],
    answer: "C) addEventListener()"
  },
  {
    id: 17,
    question: "Which of the following will write 'Hello World' to the console?",
    options: [
      "A) print('Hello World');",
      "B) console.log('Hello World');",
      "C) log('Hello World');",
      "D) output('Hello World');"
    ],
    answer: "B) console.log('Hello World');"
  },
  {
    id: 18,
    question: "What is the correct way to declare an array in JavaScript?",
    options: [
      "A) var colors = 'red', 'green', 'blue';",
      "B) var colors = ['red', 'green', 'blue'];",
      "C) var colors = (1:'red', 2:'green', 3:'blue');",
      "D) var colors = 1=('red'), 2=('green'), 3=('blue');"
    ],
    answer: "B) var colors = ['red', 'green', 'blue'];"
  },
  {
    id: 19,
    question: "What is the result of the following expression: '2' + 3 + 5?",
    options: [
      "A) 235",
      "B) 10",
      "C) 23",
      "D) Error"
    ],
    answer: "A) 235"
  },
  {
    id: 20,
    question: "How do you round the number 7.25 to the nearest integer?",
    options: [
      "A) Math.rnd(7.25)",
      "B) round(7.25)",
      "C) Math.round(7.25)",
      "D) rnd(7.25)"
    ],
    answer: "C) Math.round(7.25)"
  }
];




var num = 0;

let continueEle = document.getElementById("continue");




function createEle(){
let javascriptQuestionDivEle = document.getElementById("javascript-question-div");

  
while (javascriptQuestionDivEle.firstChild) {
javascriptQuestionDivEle.removeChild(javascriptQuestionDivEle.firstChild);}


let obj = javascriptQuestions[num]

// question
let QuestionEle = document.createElement("h1");
QuestionEle.classList.add("head");
QuestionEle.textContent=obj.id+" "+ obj.question;
javascriptQuestionDivEle.appendChild(QuestionEle)

// option

for (let option of obj.options){

let optionsEle = document.createElement("li");
optionsEle.id = option[0]

var buttonEle = document.createElement("button");

buttonEle.classList.add("btn");
buttonEle.textContent=option;

buttonEle.onclick = function(){

buttonEle.classList.toggle("select-btn");
}


optionsEle.appendChild(buttonEle)


javascriptQuestionDivEle.appendChild(optionsEle)
}

//answer
let answerButtonEle =  document.createElement("h2");
answerButtonEle.textContent ="Answer "+ obj.answer[0];
answerButtonEle.classList.add("answer-button");
javascriptQuestionDivEle.appendChild(answerButtonEle);


}

createEle();








// Intervels
let spanEle = document.getElementById("span");
let counter = 60;

let uniqueId = setInterval(function() {
  counter -= 1;
  spanEle.textContent=counter
  if (counter === 0){
  clearInterval(uniqueId);
  window.location.replace(`../Loss/YouLossPage.html`);
}
}, 1000);


continueEle.onclick = function(){

  if(num<19){
  counter = 60;
  num+=1;
  createEle();
  }
  else {
     window.location.replace(`../Win/WinPage.html`);
  }

}






