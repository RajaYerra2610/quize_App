

// localStorage.setItem("htmlQuestions", JSON.stringify(htmlQuestions));

const htmlQuestions = [
  {
    id: 1,
    question: "What does HTML stand for?",
    options: [
      "A) Hypertext Markup Language",
      "B) Hyperlink Text Markup Language",
      "C) Hypertext Multilayer Language",
      "D) Hypertext Management Language"
    ],
    answer: "A) Hypertext Markup Language"
  },
  {
    id: 2,
    question: "Which HTML element is used to define the title of a document?",
    options: [
      "A) <head>",
      "B) <title>",
      "C) <meta>",
      "D) <header>"
    ],
    answer: "B) <title>"
  },
  {
    id: 3,
    question: "How do you insert a comment in HTML?",
    options: [
      "A) <!-- This is a comment -->",
      "B) // This is a comment",
      "C) /* This is a comment */",
      "D) ** This is a comment **"
    ],
    answer: "A) <!-- This is a comment -->"
  },
  {
    id: 4,
    question: "Which tag is used to create a hyperlink in HTML?",
    options: [
      "A) <link>",
      "B) <a>",
      "C) <href>",
      "D) <hyperlink>"
    ],
    answer: "B) <a>"
  },
  {
    id: 5,
    question: "What is the correct HTML element for inserting a line break?",
    options: [
      "A) <break>",
      "B) <br>",
      "C) <lb>",
      "D) <newline>"
    ],
    answer: "B) <br>"
  },
  {
    id: 6,
    question: "Which element is used to define a table in HTML?",
    options: [
      "A) <table>",
      "B) <tab>",
      "C) <tr>",
      "D) <td>"
    ],
    answer: "A) <table>"
  },
  {
    id: 7,
    question: "How do you specify the URL of an image in HTML?",
    options: [
      "A) <img src='url'>",
      "B) <image url='url'>",
      "C) <pic src='url'>",
      "D) <img href='url'>"
    ],
    answer: "A) <img src='url'>"
  },
  {
    id: 8,
    question: "What is the correct HTML element for adding a footer?",
    options: [
      "A) <footer>",
      "B) <bottom>",
      "C) <foot>",
      "D) <section>"
    ],
    answer: "A) <footer>"
  },
  {
    id: 9,
    question: "Which HTML element is used to define the main content of a document?",
    options: [
      "A) <main>",
      "B) <content>",
      "C) <body>",
      "D) <section>"
    ],
    answer: "A) <main>"
  },
  {
    id: 10,
    question: "Which tag is used to create a numbered list?",
    options: [
      "A) <ul>",
      "B) <ol>",
      "C) <list>",
      "D) <nl>"
    ],
    answer: "B) <ol>"
  },
  {
    id: 11,
    question: "How do you create a form in HTML?",
    options: [
      "A) <form>",
      "B) <input>",
      "C) <submit>",
      "D) <field>"
    ],
    answer: "A) <form>"
  },
  {
    id: 12,
    question: "Which attribute is used to specify the destination of a link?",
    options: [
      "A) src",
      "B) href",
      "C) link",
      "D) url"
    ],
    answer: "B) href"
  },
  {
    id: 13,
    question: "Which HTML element defines the navigation section of a webpage?",
    options: [
      "A) <nav>",
      "B) <menu>",
      "C) <sidebar>",
      "D) <navigation>"
    ],
    answer: "A) <nav>"
  },
  {
    id: 14,
    question: "What is the purpose of the <meta> tag in HTML?",
    options: [
      "A) To define metadata about the HTML document",
      "B) To include JavaScript code",
      "C) To link external stylesheets",
      "D) To display images"
    ],
    answer: "A) To define metadata about the HTML document"
  },
  {
    id: 15,
    question: "Which tag is used to define a section in HTML5?",
    options: [
      "A) <section>",
      "B) <div>",
      "C) <article>",
      "D) <block>"
    ],
    answer: "A) <section>"
  },
  {
    id: 16,
    question: "How do you define a paragraph in HTML?",
    options: [
      "A) <p>",
      "B) <para>",
      "C) <text>",
      "D) <br>"
    ],
    answer: "A) <p>"
  },
  {
    id: 17,
    question: "Which HTML element is used to define a heading?",
    options: [
      "A) <h1> to <h6>",
      "B) <heading>",
      "C) <title>",
      "D) <head>"
    ],
    answer: "A) <h1> to <h6>"
  },
  {
    id: 18,
    question: "What is the correct HTML element to define important text?",
    options: [
      "A) <strong>",
      "B) <b>",
      "C) <important>",
      "D) <em>"
    ],
    answer: "A) <strong>"
  },
  {
    id: 19,
    question: "Which tag is used to define an unordered list?",
    options: [
      "A) <ul>",
      "B) <ol>",
      "C) <list>",
      "D) <ulist>"
    ],
    answer: "A) <ul>"
  },
  {
    id: 20,
    question: "How do you create a hyperlink that opens in a new tab?",
    options: [
      "A) <a href='url' target='_blank'>",
      "B) <a href='url' new-tab='true'>",
      "C) <a href='url' target='_new'>",
      "D) <link href='url' target='_blank'>"
    ],
    answer: "A) <a href='url' target='_blank'>"
  }
];









var num = 0;

let continueEle = document.getElementById("continue");




function createEle(){
let javascriptQuestionDivEle = document.getElementById("html-question-div");

  
while (javascriptQuestionDivEle.firstChild) {
javascriptQuestionDivEle.removeChild(javascriptQuestionDivEle.firstChild);}


let obj = htmlQuestions[num]

// question
let QuestionEle = document.createElement("h1");
QuestionEle.classList.add("head");
QuestionEle.textContent=obj.id+" "+ obj.question;
javascriptQuestionDivEle.appendChild(QuestionEle)

// option

for (let option of obj.options){

let optionsEle = document.createElement("li");
optionsEle.classList.add("btn");
optionsEle.textContent=option;
javascriptQuestionDivEle.appendChild(optionsEle)
}

//answer
let answerButtonEle =  document.createElement("h2");
answerButtonEle.textContent ="Answer "+ obj.answer[0];
answerButtonEle.classList.add("answer-button");
javascriptQuestionDivEle.appendChild(answerButtonEle);


}

createEle();




// Intervels
let spanEle = document.getElementById("span");
let counter = 60;

let uniqueId = setInterval(function() {
  counter -= 1;
  spanEle.textContent=counter
  if (counter === 0){
  clearInterval(uniqueId);
  window.location.replace(`../Loss/YouLossPage.html`);
}
}, 1000);


continueEle.onclick = function(){

  if(num<19){
  counter = 60;
  num+=1;
  createEle();
  }
  else{
     window.location.replace(`../Win/WinPage.html`);
  }

}
























